﻿Lie-downCraft client package placeholder.
Replace static/download/client.zip with the real client archive before release.
